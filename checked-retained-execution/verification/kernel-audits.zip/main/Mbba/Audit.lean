import Lean.Util.CollectAxioms
import J8R59WholeMenu

open Lean Elab Command
set_option maxRecDepth 10000
run_cmd
  let env ← getEnv
  let wanted : Std.HashSet String := Std.HashSet.ofList ["J8R59WholeMenu"]
  for m in wanted.toList do
    unless env.header.moduleNames.any (fun n => n.toString == m) do
      throwError "missing module {m}"
  let mut localNames : Array Name := #[]
  let mut theoremCount := 0
  let mut axiomCount := 0
  for (n, info) in env.constants.toList do
    if let some idx := env.getModuleIdxFor? n then
      if wanted.contains (env.header.moduleNames[idx.toNat]!).toString then
        localNames := localNames.push n
        if info matches .thmInfo _ then theoremCount := theoremCount + 1
        if info matches .axiomInfo _ then axiomCount := axiomCount + 1
  let (_, s) := ((localNames.forM Lean.CollectAxioms.collect).run env).run {}
  let allowed := [`propext, `Classical.choice, `Quot.sound]
  if axiomCount != 0 || !s.axioms.all (fun n => allowed.contains n) then
    throwError "unexpected axioms {s.axioms}, newly declared axioms {axiomCount}"
  logInfo m!"AUDITED declarations={localNames.size} theoremDeclarations={theoremCount} localAxioms={axiomCount} transitiveAxioms={s.axioms}"
